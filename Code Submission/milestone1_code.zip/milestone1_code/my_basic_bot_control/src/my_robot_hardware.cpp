#include "my_basic_bot_control/my_robot_hardware.hpp"
#include "hardware_interface/types/hardware_interface_type_values.hpp"
#include "rclcpp/logging.hpp"

namespace my_basic_bot_control
{

hardware_interface::CallbackReturn MyRobotHardware::on_init(const hardware_interface::HardwareInfo & info)
{
  if (hardware_interface::SystemInterface::on_init(info) != hardware_interface::CallbackReturn::SUCCESS) {
    return hardware_interface::CallbackReturn::ERROR;
  }

  hw_positions_.resize(info.joints.size(), 0.0);
  hw_velocities_.resize(info.joints.size(), 0.0);
  hw_commands_.resize(info.joints.size(), 0.0);

  return hardware_interface::CallbackReturn::SUCCESS;
}

std::vector<hardware_interface::StateInterface> MyRobotHardware::export_state_interfaces()
{
  std::vector<hardware_interface::StateInterface> state_interfaces;
  for (size_t i = 0; i < info_.joints.size(); ++i) {
    state_interfaces.emplace_back(hardware_interface::StateInterface(info_.joints[i].name, "position", &hw_positions_[i]));
    state_interfaces.emplace_back(hardware_interface::StateInterface(info_.joints[i].name, "velocity", &hw_velocities_[i]));
  }
  return state_interfaces;
}

std::vector<hardware_interface::CommandInterface> MyRobotHardware::export_command_interfaces()
{
  std::vector<hardware_interface::CommandInterface> command_interfaces;
  for (size_t i = 0; i < info_.joints.size(); ++i) {
    command_interfaces.emplace_back(hardware_interface::CommandInterface(info_.joints[i].name, "velocity", &hw_commands_[i]));
  }
  return command_interfaces;
}

hardware_interface::return_type MyRobotHardware::read(const rclcpp::Time &, const rclcpp::Duration & period)
{
  for (size_t i = 0; i < hw_positions_.size(); ++i) {
    // Use the actual period duration for simulation timestep
    hw_positions_[i] += hw_commands_[i] * period.seconds();
    hw_velocities_[i] = hw_commands_[i];

    RCLCPP_INFO(
      rclcpp::get_logger("MyRobotHardware"),
      "Joint %s -> Position: %.3f, Velocity: %.3f",
      info_.joints[i].name.c_str(),
      hw_positions_[i],
      hw_velocities_[i]
    );
  }

  return hardware_interface::return_type::OK;
}

hardware_interface::return_type MyRobotHardware::write(const rclcpp::Time &, const rclcpp::Duration &)
{
  for (size_t i = 0; i < hw_commands_.size(); ++i) {
    RCLCPP_INFO(
      rclcpp::get_logger("MyRobotHardware"),
      "Joint %s -> Commanded Velocity: %.3f",
      info_.joints[i].name.c_str(),
      hw_commands_[i]
    );
  }

  return hardware_interface::return_type::OK;
}

}  // namespace my_basic_bot_control

#include "pluginlib/class_list_macros.hpp"
PLUGINLIB_EXPORT_CLASS(my_basic_bot_control::MyRobotHardware, hardware_interface::SystemInterface)

