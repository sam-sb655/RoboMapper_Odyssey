from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.substitutions import FindPackageShare
from launch.substitutions import PathJoinSubstitution

def generate_launch_description():
    bringup_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('my_basic_bot_bringup'),
                'launch',
                'bringup_launch.py'
            ])
        ])
    )

    control_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('my_basic_bot_control'),
                'launch',
                'bringup.launch.py'
            ])
        ])
    )

    return LaunchDescription([
        bringup_launch,
        control_launch,
    ])

