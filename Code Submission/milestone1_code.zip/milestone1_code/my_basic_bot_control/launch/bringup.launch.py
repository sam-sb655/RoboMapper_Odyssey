from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import Command, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare, FindExecutable

def generate_launch_description():
    xacro_path = PathJoinSubstitution([
        FindPackageShare("my_basic_bot_description"),
        "urdf",
        "basic_bot.xacro"
    ])

    robot_description = {
        "robot_description": Command([FindExecutable(name='xacro'), xacro_path])
    }

    controller_config = PathJoinSubstitution([
        FindPackageShare("my_basic_bot_control"),
        "config",
        "ros2_controllers.yaml"
    ])

    return LaunchDescription([
        Node(
            package="robot_state_publisher",
            executable="robot_state_publisher",
            parameters=[robot_description],
            output="screen"
        ),
        Node(
            package="controller_manager",
            executable="ros2_control_node",
            parameters=[robot_description, controller_config],
            output="screen"
        ),
        Node(
            package="controller_manager",
            executable="spawner",
            arguments=["joint_state_broadcaster"],
            output="screen"
        ),
        Node(
            package="controller_manager",
            executable="spawner",
            arguments=["diff_drive_controller"],
            output="screen"
        )
    ])

