from launch import LaunchDescription
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch.substitutions import PathJoinSubstitution

def generate_launch_description():
    slam_params_file = PathJoinSubstitution([
        FindPackageShare('my_basic_bot_bringup'),
        'config',
        'slam_toolbox_params.yaml'
    ])

    rviz_config_file = PathJoinSubstitution([
        FindPackageShare('my_basic_bot_bringup'),
        'rviz',
        'slam_config.rviz'
    ])

    return LaunchDescription([
        # SLAM Toolbox node with parameters
        Node(
            package='slam_toolbox',
            executable='async_slam_toolbox_node',
            name='slam_toolbox',
            output='screen',
            parameters=[slam_params_file]
        ),

        # Teleop node for manual control
        Node(
            package='teleop_twist_keyboard',
            executable='teleop_twist_keyboard',
            name='teleop',
            output='screen',
            prefix='xterm -e',
        ),

        # RViz for visualization
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', rviz_config_file],
            output='screen'
        ),
    ])

