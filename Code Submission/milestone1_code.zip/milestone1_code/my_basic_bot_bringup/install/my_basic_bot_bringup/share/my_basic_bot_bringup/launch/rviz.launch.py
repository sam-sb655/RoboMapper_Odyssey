from launch import LaunchDescription
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
import os

def generate_launch_description():
    rviz_config_file = os.path.join(
        FindPackageShare("my_basic_bot_bringup").find("my_basic_bot_bringup"),
        "rviz",
        "my_basic_bot.rviz"
    )

    return LaunchDescription([
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', rviz_config_file],
            output='screen'
        )
    ])

