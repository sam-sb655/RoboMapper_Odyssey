from setuptools import find_packages, setup

package_name = 'my_basic_bot_description'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/urdf', ['urdf/basic_bot.xacro', 'urdf/wheel.xacro', 'urdf/chassis.xacro']),
        ('share/' + package_name + '/launch', ['launch/robot_description.launch.py', 'launch/view_robot.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ubuntu',
    maintainer_email='ubuntu@todo.todo',
    description='Basic bot URDF description package',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [],
    },
)

